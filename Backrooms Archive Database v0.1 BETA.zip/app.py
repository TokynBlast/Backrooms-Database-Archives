import os

def read_level(filename):
    with open(filename, "r") as f:
        data = f.readlines()
    return ''.join(data)

def display_level(data):
    os.system('cls' if os.name == 'nt' else 'clear')
    for row in data.split('\n'):
        print(row.strip())

while True:
    choice = input("")
    full_path = os.path.join('data', f"{choice}.txt")
    if os.path.exists(full_path):
        data = read_level(full_path)
        display_level(data)
        input("")
        os.system('cls' if os.name == 'nt' else 'clear')
    else:
        print("Invalid. Try something else")